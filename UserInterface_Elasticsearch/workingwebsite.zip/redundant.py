# ORIGINAL
# <form id="search_field" action="/" method="post">
# 		<div class="row">
# 		  <div class="col-lg-6">
# 		    <div class="input-group">
# 		      <input name="query" type="text" class="form-control" placeholder="Search for...">
# 		      <span class="input-group-btn glyphicon-search">
# 		        <input class="btn btn-default" type="submit">Go!</input>
# 		      </span>
# 		    </div><!-- /input-group -->
# 		  </div><!-- /.col-lg-6 -->
# 		</div><!-- /.row -->
# 	</form>




# <form action="/" class="navbar-form" method="post">
#   <div class="input-group">
#       <input name="query" type="Search" placeholder="Search..." class="form-control" />
#       <div class="input-group-btn">
#           <button class="btn btn-info">
#           <span class="glyphicon glyphicon-search"></span>
#           </button>
#       </div>
#   	</div>
# </form>


# style="width: 15em; margin: 1.2em 1em;"
# <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">